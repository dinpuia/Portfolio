---
title: About Me
profile_image: /images/uploads/profile.jpg
---

I'm Dinpui, a self-taught graphic designer with a passion for clean design and bold visuals. I turn ideas into visuals that speak louder than words.
